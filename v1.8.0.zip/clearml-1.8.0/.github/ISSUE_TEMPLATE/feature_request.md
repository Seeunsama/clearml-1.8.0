---
name: Feature Request
about: Suggest an idea for ClearML
title: ''
assignees: ''

---

## Proposal Summary
Explain your proposed feature.

## Motivation
Explain the use case that needs this feature

## Related Discussion
If this continues a slack thread, please provide a link to the original slack thread. 