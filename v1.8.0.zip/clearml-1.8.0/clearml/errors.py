class UsageError(RuntimeError):
    """ An exception raised for illegal usage of clearml objects"""
    pass
